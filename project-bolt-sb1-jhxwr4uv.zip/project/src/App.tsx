import React, { useState } from 'react';
import { Header } from './components/Header';
import { PersonalInfoForm } from './components/PersonalInfoForm';
import { ExperienceForm } from './components/ExperienceForm';
import { EducationForm } from './components/EducationForm';
import { SkillsForm } from './components/SkillsForm';
import { ResumePreview } from './components/ResumePreview';
import { AIAssistant } from './components/AIAssistant';
import { useResumeData } from './hooks/useResumeData';
import { User, Briefcase, GraduationCap, Zap, FolderOpen, Award } from 'lucide-react';

function App() {
  const {
    resumeData,
    updatePersonalInfo,
    addExperience,
    updateExperience,
    deleteExperience,
    addEducation,
    updateEducation,
    deleteEducation,
    addSkill,
    deleteSkill,
    addProject,
    deleteProject,
    addCertificate,
    deleteCertificate
  } = useResumeData();

  const [showPreview, setShowPreview] = useState(false);
  const [showAIAssistant, setShowAIAssistant] = useState(false);
  const [activeSection, setActiveSection] = useState('personal');

  const handleDownloadPDF = async () => {
    try {
      const html2canvas = (await import('html2canvas')).default;
      const jsPDF = (await import('jspdf')).default;

      const element = document.getElementById('resume-content');
      if (!element) return;

      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        allowTaint: true
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgWidth = 210;
      const pageHeight = 295;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;

      let position = 0;

      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`${resumeData.personalInfo.fullName || 'Resume'}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Error generating PDF. Please try again.');
    }
  };

  const sections = [
    { id: 'personal', name: 'Personal Info', icon: User },
    { id: 'experience', name: 'Experience', icon: Briefcase },
    { id: 'education', name: 'Education', icon: GraduationCap },
    { id: 'skills', name: 'Skills', icon: Zap },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <Header
        onPreview={() => setShowPreview(true)}
        onDownload={handleDownloadPDF}
        onAIAssist={() => setShowAIAssistant(true)}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar Navigation */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 sticky top-24">
              <h3 className="font-semibold text-gray-900 mb-4">Resume Sections</h3>
              <nav className="space-y-2">
                {sections.map((section) => (
                  <button
                    key={section.id}
                    onClick={() => setActiveSection(section.id)}
                    className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors duration-200 ${
                      activeSection === section.id
                        ? 'bg-blue-50 text-blue-700 border border-blue-200'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <section.icon className="h-4 w-4" />
                    <span className="text-sm font-medium">{section.name}</span>
                  </button>
                ))}
              </nav>

              <div className="mt-6 pt-4 border-t border-gray-200">
                <div className="text-center">
                  <div className="bg-gradient-to-r from-green-400 to-blue-500 text-white p-3 rounded-lg mb-3">
                    <p className="text-sm font-medium">Resume Score</p>
                    <p className="text-2xl font-bold">
                      {Math.round(
                        (resumeData.personalInfo.fullName ? 10 : 0) +
                        (resumeData.personalInfo.email ? 10 : 0) +
                        (resumeData.personalInfo.summary ? 15 : 0) +
                        (resumeData.experience.length > 0 ? 25 : 0) +
                        (resumeData.education.length > 0 ? 15 : 0) +
                        (resumeData.skills.length > 0 ? 15 : 0) +
                        (resumeData.projects.length > 0 ? 10 : 0)
                      )}%
                    </p>
                  </div>
                  <p className="text-xs text-gray-500">
                    Complete all sections for a higher score
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {activeSection === 'personal' && (
              <PersonalInfoForm
                data={resumeData.personalInfo}
                onChange={updatePersonalInfo}
              />
            )}

            {activeSection === 'experience' && (
              <ExperienceForm
                experiences={resumeData.experience}
                onAdd={addExperience}
                onUpdate={updateExperience}
                onDelete={deleteExperience}
              />
            )}

            {activeSection === 'education' && (
              <EducationForm
                education={resumeData.education}
                onAdd={addEducation}
                onUpdate={updateEducation}
                onDelete={deleteEducation}
              />
            )}

            {activeSection === 'skills' && (
              <SkillsForm
                skills={resumeData.skills}
                onAdd={addSkill}
                onDelete={deleteSkill}
              />
            )}
          </div>
        </div>
      </div>

      {showPreview && (
        <ResumePreview
          data={resumeData}
          onClose={() => setShowPreview(false)}
          onDownload={handleDownloadPDF}
        />
      )}

      {showAIAssistant && (
        <AIAssistant
          data={resumeData}
          onClose={() => setShowAIAssistant(false)}
        />
      )}
    </div>
  );
}

export default App;