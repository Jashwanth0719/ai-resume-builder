import { Template } from '../types';

export const templates: Template[] = [
  {
    id: 'modern-professional',
    name: 'Modern Professional',
    description: 'Clean, modern design perfect for tech and business roles',
    preview: 'https://images.pexels.com/photos/590016/pexels-photo-590016.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Modern'
  },
  {
    id: 'classic-elegant',
    name: 'Classic Elegant',
    description: 'Traditional layout ideal for corporate and finance positions',
    preview: 'https://images.pexels.com/photos/590020/pexels-photo-590020.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Classic'
  },
  {
    id: 'creative-bold',
    name: 'Creative Bold',
    description: 'Eye-catching design for creative and design professionals',
    preview: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Creative'
  },
  {
    id: 'minimal-clean',
    name: 'Minimal Clean',
    description: 'Simple, focused layout that highlights your content',
    preview: 'https://images.pexels.com/photos/590018/pexels-photo-590018.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Minimal'
  }
];

export const aiSuggestions = [
  "Use action verbs to start bullet points (e.g., 'Developed', 'Implemented', 'Led')",
  "Quantify achievements with specific numbers and percentages",
  "Tailor your summary to match the job description keywords",
  "Keep bullet points concise and impactful (1-2 lines max)",
  "Include relevant technical skills for your industry",
  "Use consistent formatting throughout your resume",
  "Highlight leadership and teamwork experiences",
  "Include measurable results and accomplishments"
];