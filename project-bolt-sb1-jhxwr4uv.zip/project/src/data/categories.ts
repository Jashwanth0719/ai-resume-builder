import { Category } from '../types';

export const categories: Category[] = [
  { name: 'Food', icon: 'utensils', color: 'bg-red-500' },
  { name: 'Transportation', icon: 'car', color: 'bg-blue-500' },
  { name: 'Books', icon: 'book', color: 'bg-green-500' },
  { name: 'Entertainment', icon: 'gamepad-2', color: 'bg-purple-500' },
  { name: 'Clothes', icon: 'shirt', color: 'bg-pink-500' },
  { name: 'Health', icon: 'heart', color: 'bg-red-400' },
  { name: 'Housing', icon: 'home', color: 'bg-indigo-500' },
  { name: 'Technology', icon: 'laptop', color: 'bg-gray-600' },
  { name: 'Other', icon: 'more-horizontal', color: 'bg-gray-400' },
];

export const incomeCategories: Category[] = [
  { name: 'Allowance', icon: 'coins', color: 'bg-green-500' },
  { name: 'Part-time Job', icon: 'briefcase', color: 'bg-blue-500' },
  { name: 'Scholarship', icon: 'graduation-cap', color: 'bg-yellow-500' },
  { name: 'Gift', icon: 'gift', color: 'bg-purple-500' },
  { name: 'Other Income', icon: 'plus-circle', color: 'bg-gray-500' },
];