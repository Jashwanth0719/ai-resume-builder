import React from 'react';
import { TrendingUp, TrendingDown, DollarSign, Target } from 'lucide-react';
import { Expense, Budget } from '../types';

interface DashboardProps {
  expenses: Expense[];
  budgets: Budget[];
}

export function Dashboard({ expenses, budgets }: DashboardProps) {
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  
  const monthlyExpenses = expenses.filter(expense => {
    const expenseDate = new Date(expense.date);
    return expenseDate.getMonth() === currentMonth && 
           expenseDate.getFullYear() === currentYear &&
           expense.type === 'expense';
  });

  const monthlyIncome = expenses.filter(expense => {
    const expenseDate = new Date(expense.date);
    return expenseDate.getMonth() === currentMonth && 
           expenseDate.getFullYear() === currentYear &&
           expense.type === 'income';
  });

  const totalExpenses = monthlyExpenses.reduce((sum, expense) => sum + expense.amount, 0);
  const totalIncome = monthlyIncome.reduce((sum, income) => sum + income.amount, 0);
  const totalBudget = budgets.reduce((sum, budget) => sum + budget.limit, 0);
  const budgetUsed = (totalExpenses / totalBudget) * 100;

  const stats = [
    {
      title: 'Monthly Income',
      value: `$${totalIncome.toFixed(2)}`,
      icon: TrendingUp,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
    },
    {
      title: 'Monthly Expenses',
      value: `$${totalExpenses.toFixed(2)}`,
      icon: TrendingDown,
      color: 'text-red-600',
      bgColor: 'bg-red-50',
    },
    {
      title: 'Net Balance',
      value: `$${(totalIncome - totalExpenses).toFixed(2)}`,
      icon: DollarSign,
      color: totalIncome - totalExpenses >= 0 ? 'text-green-600' : 'text-red-600',
      bgColor: totalIncome - totalExpenses >= 0 ? 'bg-green-50' : 'bg-red-50',
    },
    {
      title: 'Budget Used',
      value: `${budgetUsed.toFixed(1)}%`,
      icon: Target,
      color: budgetUsed > 90 ? 'text-red-600' : budgetUsed > 70 ? 'text-yellow-600' : 'text-green-600',
      bgColor: budgetUsed > 90 ? 'bg-red-50' : budgetUsed > 70 ? 'bg-yellow-50' : 'bg-green-50',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {stats.map((stat, index) => (
        <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow duration-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 mb-1">{stat.title}</p>
              <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
            </div>
            <div className={`p-3 rounded-lg ${stat.bgColor}`}>
              <stat.icon className={`h-6 w-6 ${stat.color}`} />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}