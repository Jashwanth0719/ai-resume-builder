import React from 'react';
import { FileText, Download, Eye, Sparkles } from 'lucide-react';

interface HeaderProps {
  onPreview: () => void;
  onDownload: () => void;
  onAIAssist: () => void;
}

export function Header({ onPreview, onDownload, onAIAssist }: HeaderProps) {
  return (
    <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-2 rounded-lg">
              <FileText className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">AI Resume Builder</h1>
              <p className="text-sm text-gray-500">Create professional resumes with AI assistance</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <button
              onClick={onAIAssist}
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-all duration-200 shadow-md hover:shadow-lg"
            >
              <Sparkles className="h-4 w-4" />
              <span>AI Assist</span>
            </button>
            <button
              onClick={onPreview}
              className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors duration-200"
            >
              <Eye className="h-4 w-4" />
              <span>Preview</span>
            </button>
            <button
              onClick={onDownload}
              className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors duration-200"
            >
              <Download className="h-4 w-4" />
              <span>Download PDF</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}