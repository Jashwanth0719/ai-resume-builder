import React, { useState } from 'react';
import { X, Sparkles, Lightbulb, CheckCircle, AlertCircle } from 'lucide-react';
import { ResumeData } from '../types';
import { aiSuggestions } from '../data/templates';

interface AIAssistantProps {
  data: ResumeData;
  onClose: () => void;
}

export function AIAssistant({ data, onClose }: AIAssistantProps) {
  const [activeTab, setActiveTab] = useState<'suggestions' | 'analysis'>('suggestions');

  const analyzeResume = () => {
    const analysis = {
      completeness: 0,
      issues: [] as string[],
      strengths: [] as string[]
    };

    // Check completeness
    if (data.personalInfo.fullName) analysis.completeness += 10;
    if (data.personalInfo.email) analysis.completeness += 10;
    if (data.personalInfo.phone) analysis.completeness += 10;
    if (data.personalInfo.summary) analysis.completeness += 15;
    if (data.experience.length > 0) analysis.completeness += 25;
    if (data.education.length > 0) analysis.completeness += 15;
    if (data.skills.length > 0) analysis.completeness += 15;

    // Identify issues
    if (!data.personalInfo.summary) {
      analysis.issues.push('Missing professional summary - this is crucial for making a strong first impression');
    }
    if (data.experience.length === 0) {
      analysis.issues.push('No work experience listed - consider adding internships, part-time jobs, or volunteer work');
    }
    if (data.skills.length < 5) {
      analysis.issues.push('Limited skills listed - add more relevant technical and soft skills');
    }
    if (data.experience.some(exp => exp.description.some(desc => desc.length < 20))) {
      analysis.issues.push('Some job descriptions are too brief - expand with specific achievements and metrics');
    }

    // Identify strengths
    if (data.personalInfo.summary && data.personalInfo.summary.length > 100) {
      analysis.strengths.push('Comprehensive professional summary that showcases your value proposition');
    }
    if (data.experience.length >= 2) {
      analysis.strengths.push('Good work experience history showing career progression');
    }
    if (data.skills.length >= 8) {
      analysis.strengths.push('Diverse skill set that demonstrates versatility');
    }
    if (data.projects.length > 0) {
      analysis.strengths.push('Project portfolio showcases practical application of skills');
    }

    return analysis;
  };

  const analysis = analyzeResume();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-hidden">
        <div className="flex justify-between items-center p-6 border-b border-gray-200 bg-gradient-to-r from-purple-500 to-pink-500">
          <div className="flex items-center space-x-2 text-white">
            <Sparkles className="h-6 w-6" />
            <h2 className="text-xl font-semibold">AI Resume Assistant</h2>
          </div>
          <button
            onClick={onClose}
            className="text-white hover:text-gray-200 transition-colors duration-200"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="flex border-b border-gray-200">
          <button
            onClick={() => setActiveTab('suggestions')}
            className={`flex-1 px-6 py-3 text-sm font-medium transition-colors duration-200 ${
              activeTab === 'suggestions'
                ? 'text-purple-600 border-b-2 border-purple-600 bg-purple-50'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <Lightbulb className="h-4 w-4 inline mr-2" />
            Writing Tips
          </button>
          <button
            onClick={() => setActiveTab('analysis')}
            className={`flex-1 px-6 py-3 text-sm font-medium transition-colors duration-200 ${
              activeTab === 'analysis'
                ? 'text-purple-600 border-b-2 border-purple-600 bg-purple-50'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <CheckCircle className="h-4 w-4 inline mr-2" />
            Resume Analysis
          </button>
        </div>

        <div className="overflow-y-auto max-h-[calc(90vh-140px)] p-6">
          {activeTab === 'suggestions' && (
            <div className="space-y-4">
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg border border-blue-200">
                <h3 className="font-semibold text-gray-900 mb-2 flex items-center">
                  <Sparkles className="h-4 w-4 text-purple-600 mr-2" />
                  AI-Powered Writing Tips
                </h3>
                <p className="text-sm text-gray-600">
                  Follow these expert recommendations to create a compelling, ATS-friendly resume that stands out to employers.
                </p>
              </div>

              <div className="space-y-3">
                {aiSuggestions.map((suggestion, index) => (
                  <div key={index} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                    <div className="bg-purple-100 p-1 rounded-full mt-0.5">
                      <Lightbulb className="h-3 w-3 text-purple-600" />
                    </div>
                    <p className="text-sm text-gray-700 leading-relaxed">{suggestion}</p>
                  </div>
                ))}
              </div>

              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mt-6">
                <h4 className="font-medium text-yellow-800 mb-2">Pro Tip</h4>
                <p className="text-sm text-yellow-700">
                  Customize your resume for each job application by incorporating keywords from the job description. 
                  This helps your resume pass through Applicant Tracking Systems (ATS) and shows employers you're a perfect fit.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'analysis' && (
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-green-50 to-blue-50 p-4 rounded-lg border border-green-200">
                <h3 className="font-semibold text-gray-900 mb-2 flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                  Resume Completeness Score
                </h3>
                <div className="flex items-center space-x-3">
                  <div className="flex-1 bg-gray-200 rounded-full h-3">
                    <div
                      className="bg-gradient-to-r from-green-500 to-blue-500 h-3 rounded-full transition-all duration-500"
                      style={{ width: `${analysis.completeness}%` }}
                    />
                  </div>
                  <span className="text-lg font-bold text-gray-900">{analysis.completeness}%</span>
                </div>
                <p className="text-sm text-gray-600 mt-2">
                  {analysis.completeness >= 80 ? 'Excellent! Your resume is comprehensive.' :
                   analysis.completeness >= 60 ? 'Good progress! A few more sections would help.' :
                   'Your resume needs more content to be competitive.'}
                </p>
              </div>

              {analysis.strengths.length > 0 && (
                <div>
                  <h4 className="font-semibold text-green-700 mb-3 flex items-center">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Strengths
                  </h4>
                  <div className="space-y-2">
                    {analysis.strengths.map((strength, index) => (
                      <div key={index} className="flex items-start space-x-3 p-3 bg-green-50 rounded-lg border border-green-200">
                        <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <p className="text-sm text-green-800">{strength}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {analysis.issues.length > 0 && (
                <div>
                  <h4 className="font-semibold text-amber-700 mb-3 flex items-center">
                    <AlertCircle className="h-4 w-4 mr-2" />
                    Areas for Improvement
                  </h4>
                  <div className="space-y-2">
                    {analysis.issues.map((issue, index) => (
                      <div key={index} className="flex items-start space-x-3 p-3 bg-amber-50 rounded-lg border border-amber-200">
                        <AlertCircle className="h-4 w-4 text-amber-600 mt-0.5 flex-shrink-0" />
                        <p className="text-sm text-amber-800">{issue}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-medium text-blue-800 mb-2">Next Steps</h4>
                <ul className="text-sm text-blue-700 space-y-1 list-disc list-inside">
                  <li>Address the improvement areas identified above</li>
                  <li>Use action verbs and quantify your achievements</li>
                  <li>Tailor your resume for each job application</li>
                  <li>Have someone review your resume for feedback</li>
                  <li>Keep your resume updated with new experiences</li>
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}