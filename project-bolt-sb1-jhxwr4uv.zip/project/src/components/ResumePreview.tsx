import React from 'react';
import { X, Download } from 'lucide-react';
import { ResumeData } from '../types';

interface ResumePreviewProps {
  data: ResumeData;
  onClose: () => void;
  onDownload: () => void;
}

export function ResumePreview({ data, onClose, onDownload }: ResumePreviewProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        <div className="flex justify-between items-center p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Resume Preview</h2>
          <div className="flex space-x-2">
            <button
              onClick={onDownload}
              className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors duration-200"
            >
              <Download className="h-4 w-4" />
              <span>Download PDF</span>
            </button>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors duration-200"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        <div className="overflow-y-auto max-h-[calc(90vh-80px)]">
          <div id="resume-content" className="bg-white p-8 max-w-[8.5in] mx-auto" style={{ minHeight: '11in' }}>
            {/* Header */}
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">{data.personalInfo.fullName}</h1>
              <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-600">
                {data.personalInfo.email && <span>{data.personalInfo.email}</span>}
                {data.personalInfo.phone && <span>{data.personalInfo.phone}</span>}
                {data.personalInfo.location && <span>{data.personalInfo.location}</span>}
              </div>
              <div className="flex flex-wrap justify-center gap-4 text-sm text-blue-600 mt-2">
                {data.personalInfo.website && <a href={data.personalInfo.website} className="hover:underline">Website</a>}
                {data.personalInfo.linkedin && <a href={data.personalInfo.linkedin} className="hover:underline">LinkedIn</a>}
                {data.personalInfo.github && <a href={data.personalInfo.github} className="hover:underline">GitHub</a>}
              </div>
            </div>

            {/* Summary */}
            {data.personalInfo.summary && (
              <div className="mb-8">
                <h2 className="text-xl font-bold text-gray-900 mb-3 border-b-2 border-blue-500 pb-1">Professional Summary</h2>
                <p className="text-gray-700 leading-relaxed">{data.personalInfo.summary}</p>
              </div>
            )}

            {/* Experience */}
            {data.experience.length > 0 && (
              <div className="mb-8">
                <h2 className="text-xl font-bold text-gray-900 mb-4 border-b-2 border-blue-500 pb-1">Work Experience</h2>
                <div className="space-y-6">
                  {data.experience.map((exp) => (
                    <div key={exp.id}>
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">{exp.position}</h3>
                          <p className="text-blue-600 font-medium">{exp.company}</p>
                        </div>
                        <div className="text-right text-sm text-gray-600">
                          <p>{exp.location}</p>
                          <p>{exp.startDate} - {exp.current ? 'Present' : exp.endDate}</p>
                        </div>
                      </div>
                      <ul className="list-disc list-inside text-gray-700 space-y-1 ml-4">
                        {exp.description.map((desc, index) => (
                          <li key={index}>{desc}</li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Education */}
            {data.education.length > 0 && (
              <div className="mb-8">
                <h2 className="text-xl font-bold text-gray-900 mb-4 border-b-2 border-blue-500 pb-1">Education</h2>
                <div className="space-y-4">
                  {data.education.map((edu) => (
                    <div key={edu.id} className="flex justify-between items-start">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">{edu.degree} in {edu.field}</h3>
                        <p className="text-blue-600 font-medium">{edu.institution}</p>
                        {(edu.gpa || edu.honors) && (
                          <p className="text-sm text-gray-600">
                            {edu.gpa && `GPA: ${edu.gpa}`}
                            {edu.gpa && edu.honors && ' • '}
                            {edu.honors}
                          </p>
                        )}
                      </div>
                      <div className="text-right text-sm text-gray-600">
                        <p>{edu.location}</p>
                        <p>{edu.startDate} - {edu.endDate}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Skills */}
            {data.skills.length > 0 && (
              <div className="mb-8">
                <h2 className="text-xl font-bold text-gray-900 mb-4 border-b-2 border-blue-500 pb-1">Skills</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {['Technical', 'Language', 'Soft', 'Other'].map(category => {
                    const categorySkills = data.skills.filter(skill => skill.category === category);
                    if (categorySkills.length === 0) return null;
                    
                    return (
                      <div key={category}>
                        <h3 className="font-semibold text-gray-900 mb-2">{category} Skills</h3>
                        <div className="flex flex-wrap gap-2">
                          {categorySkills.map(skill => (
                            <span key={skill.id} className="bg-gray-100 text-gray-800 px-2 py-1 rounded text-sm">
                              {skill.name}
                            </span>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Projects */}
            {data.projects.length > 0 && (
              <div className="mb-8">
                <h2 className="text-xl font-bold text-gray-900 mb-4 border-b-2 border-blue-500 pb-1">Projects</h2>
                <div className="space-y-4">
                  {data.projects.map((project) => (
                    <div key={project.id}>
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="text-lg font-semibold text-gray-900">{project.name}</h3>
                        <div className="flex space-x-2 text-sm">
                          {project.url && <a href={project.url} className="text-blue-600 hover:underline">Live Demo</a>}
                          {project.github && <a href={project.github} className="text-blue-600 hover:underline">GitHub</a>}
                        </div>
                      </div>
                      <p className="text-gray-700 mb-2">{project.description}</p>
                      <div className="flex flex-wrap gap-2">
                        {project.technologies.map((tech, index) => (
                          <span key={index} className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Certificates */}
            {data.certificates.length > 0 && (
              <div className="mb-8">
                <h2 className="text-xl font-bold text-gray-900 mb-4 border-b-2 border-blue-500 pb-1">Certifications</h2>
                <div className="space-y-2">
                  {data.certificates.map((cert) => (
                    <div key={cert.id} className="flex justify-between items-center">
                      <div>
                        <h3 className="font-semibold text-gray-900">{cert.name}</h3>
                        <p className="text-gray-600">{cert.issuer}</p>
                      </div>
                      <div className="text-right text-sm text-gray-600">
                        <p>{cert.date}</p>
                        {cert.url && <a href={cert.url} className="text-blue-600 hover:underline">View Certificate</a>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}