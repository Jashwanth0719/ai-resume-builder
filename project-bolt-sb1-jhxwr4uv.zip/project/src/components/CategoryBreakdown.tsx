import React from 'react';
import { PieChart } from 'lucide-react';
import { Expense } from '../types';
import { categories } from '../data/categories';

interface CategoryBreakdownProps {
  expenses: Expense[];
}

export function CategoryBreakdown({ expenses }: CategoryBreakdownProps) {
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  
  const monthlyExpenses = expenses.filter(expense => {
    const expenseDate = new Date(expense.date);
    return expenseDate.getMonth() === currentMonth && 
           expenseDate.getFullYear() === currentYear &&
           expense.type === 'expense';
  });

  const categoryTotals = categories.map(category => {
    const total = monthlyExpenses
      .filter(expense => expense.category === category.name)
      .reduce((sum, expense) => sum + expense.amount, 0);
    return { ...category, total };
  }).filter(category => category.total > 0);

  const totalExpenses = categoryTotals.reduce((sum, category) => sum + category.total, 0);

  if (categoryTotals.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center space-x-2 mb-4">
          <PieChart className="h-5 w-5 text-gray-600" />
          <h2 className="text-lg font-semibold text-gray-900">Category Breakdown</h2>
        </div>
        <div className="text-center py-8 text-gray-500">
          <PieChart className="h-12 w-12 mx-auto mb-4 text-gray-300" />
          <p>No expenses this month</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center space-x-2 mb-6">
        <PieChart className="h-5 w-5 text-gray-600" />
        <h2 className="text-lg font-semibold text-gray-900">Category Breakdown</h2>
      </div>

      <div className="space-y-4">
        {categoryTotals
          .sort((a, b) => b.total - a.total)
          .map((category) => {
            const percentage = (category.total / totalExpenses) * 100;
            return (
              <div key={category.name} className="space-y-2">
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded-full ${category.color}`} />
                    <span className="text-sm font-medium text-gray-700">{category.name}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-semibold text-gray-900">
                      ${category.total.toFixed(2)}
                    </span>
                    <span className="text-xs text-gray-500 ml-2">
                      {percentage.toFixed(1)}%
                    </span>
                  </div>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full ${category.color} transition-all duration-300`}
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
      </div>

      <div className="mt-6 pt-4 border-t border-gray-200">
        <div className="flex justify-between items-center">
          <span className="font-medium text-gray-900">Total Expenses</span>
          <span className="font-semibold text-lg text-gray-900">
            ${totalExpenses.toFixed(2)}
          </span>
        </div>
      </div>
    </div>
  );
}