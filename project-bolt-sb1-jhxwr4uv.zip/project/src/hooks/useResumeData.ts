import { useState, useEffect } from 'react';
import { ResumeData } from '../types';

const defaultResumeData: ResumeData = {
  personalInfo: {
    fullName: '',
    email: '',
    phone: '',
    location: '',
    website: '',
    linkedin: '',
    github: '',
    summary: ''
  },
  experience: [],
  education: [],
  skills: [],
  projects: [],
  certificates: []
};

export function useResumeData() {
  const [resumeData, setResumeData] = useState<ResumeData>(() => {
    try {
      const saved = localStorage.getItem('resumeData');
      return saved ? JSON.parse(saved) : defaultResumeData;
    } catch {
      return defaultResumeData;
    }
  });

  useEffect(() => {
    localStorage.setItem('resumeData', JSON.stringify(resumeData));
  }, [resumeData]);

  const updatePersonalInfo = (info: Partial<ResumeData['personalInfo']>) => {
    setResumeData(prev => ({
      ...prev,
      personalInfo: { ...prev.personalInfo, ...info }
    }));
  };

  const addExperience = (experience: Omit<ResumeData['experience'][0], 'id'>) => {
    setResumeData(prev => ({
      ...prev,
      experience: [...prev.experience, { ...experience, id: Date.now().toString() }]
    }));
  };

  const updateExperience = (id: string, updates: Partial<ResumeData['experience'][0]>) => {
    setResumeData(prev => ({
      ...prev,
      experience: prev.experience.map(exp => exp.id === id ? { ...exp, ...updates } : exp)
    }));
  };

  const deleteExperience = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      experience: prev.experience.filter(exp => exp.id !== id)
    }));
  };

  const addEducation = (education: Omit<ResumeData['education'][0], 'id'>) => {
    setResumeData(prev => ({
      ...prev,
      education: [...prev.education, { ...education, id: Date.now().toString() }]
    }));
  };

  const updateEducation = (id: string, updates: Partial<ResumeData['education'][0]>) => {
    setResumeData(prev => ({
      ...prev,
      education: prev.education.map(edu => edu.id === id ? { ...edu, ...updates } : edu)
    }));
  };

  const deleteEducation = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      education: prev.education.filter(edu => edu.id !== id)
    }));
  };

  const addSkill = (skill: Omit<ResumeData['skills'][0], 'id'>) => {
    setResumeData(prev => ({
      ...prev,
      skills: [...prev.skills, { ...skill, id: Date.now().toString() }]
    }));
  };

  const deleteSkill = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      skills: prev.skills.filter(skill => skill.id !== id)
    }));
  };

  const addProject = (project: Omit<ResumeData['projects'][0], 'id'>) => {
    setResumeData(prev => ({
      ...prev,
      projects: [...prev.projects, { ...project, id: Date.now().toString() }]
    }));
  };

  const deleteProject = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      projects: prev.projects.filter(project => project.id !== id)
    }));
  };

  const addCertificate = (certificate: Omit<ResumeData['certificates'][0], 'id'>) => {
    setResumeData(prev => ({
      ...prev,
      certificates: [...prev.certificates, { ...certificate, id: Date.now().toString() }]
    }));
  };

  const deleteCertificate = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      certificates: prev.certificates.filter(cert => cert.id !== id)
    }));
  };

  return {
    resumeData,
    updatePersonalInfo,
    addExperience,
    updateExperience,
    deleteExperience,
    addEducation,
    updateEducation,
    deleteEducation,
    addSkill,
    deleteSkill,
    addProject,
    deleteProject,
    addCertificate,
    deleteCertificate
  };
}